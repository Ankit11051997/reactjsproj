import React from "react";
 export default function ErrorPage(){
     return(<div>
        <h1>
        ERROR ! PAGE NOT FOUND
        </h1>
        </div>)
 }