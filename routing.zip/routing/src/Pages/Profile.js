import React from "react";
import { useNavigate,useParams } from "react-router-dom";
export default function Profile(){
let {username}=useParams();
let navigate=useNavigate();

    return(<div><h1>This is The Profile Page for {username}</h1><button onClick={()=>{navigate("/about")}}>{" "}Chnage to About page</button></div>);
}
