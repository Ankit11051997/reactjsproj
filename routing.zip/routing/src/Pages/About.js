import React from "react";

export default function About(){
    return(<div><h1>This is About Page</h1></div>);
}
