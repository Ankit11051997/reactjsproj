import React from 'react'
const FormSuccess = () => {
    return (
        <div>
         <div className="form-succes ">
         <h2>We have received your request</h2>
         </div>  
        </div>
    )
}

export default FormSuccess
